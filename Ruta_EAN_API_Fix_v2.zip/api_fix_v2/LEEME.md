Corrección API v2

Extraer en la raíz del proyecto; aparece api_fix_v2/.
Detener Uvicorn, ejecutar python api_fix_v2/apply_fix_v2.py y las seis pruebas:
python -m unittest discover -s tests/unit -p 'test_academic_path_v1.py' -v
Arrancar: uvicorn apps.api.src.main:app --port 8001 --reload

Corrige el ID de ModuloEANX: usa modulo_id en vez de eanx_id, que también existe en módulos y referencia el curso padre. Corrige igualmente los IDs de nodos en recorridos. Esto permite recuperar módulos y sus cursos contenedores por las relaciones reales.
Compacta recorridos repetidos y sus versiones inversas, conserva origenes_consulta y cuenta afinidades únicas en total_conexiones_recuperadas. Añade total_recorridos.
Si la búsqueda de unidades es estricta o tolerante, los programas por unidades se obtienen exclusivamente de esas unidades, sin extender el resultado usando otras unidades de búsqueda relajada. Si la unidad no tiene programa asociado, se conserva esa ausencia explícita.

La respuesta adjunta antes del cambio tenía 18 recorridos con 3 afinidades únicas. Se verificó que se compacta a 6 recorridos. No se ejecutó aquí el POST actualizado contra Neo4j real; repetir la consulta de Java para verificar ID, contenedores y programas después del cambio.
