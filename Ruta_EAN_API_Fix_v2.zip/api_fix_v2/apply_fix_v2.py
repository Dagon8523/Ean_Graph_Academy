"""Aplica la corrección v2 a una API ya migrada."""
from pathlib import Path
from datetime import datetime, timezone
import shutil

root = Path.cwd()
package = Path(__file__).resolve().parent
files = ["src/repositories/recommendation_repository.py", "src/services/recommendation_service.py",
         "apps/api/src/schemas/academic_path.py", "tests/unit/test_academic_path_v1.py"]
if not (root / "apps/api/src/main.py").is_file():
    raise SystemExit("Ejecutar desde la raíz del proyecto, después de migrar la API.")
for name in files:
    compile((package / name).read_text(encoding="utf-8"), name, "exec")
    if not (root / name).is_file():
        raise SystemExit("Falta el archivo instalado: " + name)
backup = root / "data/interim/api_fix_backups" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
for name in files:
    saved = backup / name
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, saved)
try:
    for name in files:
        shutil.copy2(package / name, root / name)
except Exception:
    for name in files:
        shutil.copy2(backup / name, root / name)
    raise
print("Corrección v2 aplicada. Respaldo:", backup)
print("No se modificó Neo4j ni sus relaciones.")
